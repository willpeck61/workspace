<div class="tblfootcontain">
<section id="showselect">
<table id="currenttbl">
	<thead>
	<tr>
		<th class="tblhead" colspan="6">CURRENT SELECTION</th>
    </tr>
    <tr>
    	<th class="tblsubhead" colspan="6">Selected..</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    	<td id="coname">Customer</td><td class="tblinfo" id="dataname">Mr W Peck</td>
    </tr>
    <tr>
        <td id="coreg">Vehicle</td><td class="tblinfo" id="dataveh">Nissan Micra 1.0s</td>
    </tr> 
    <tr>
        <td id="coemp">Registration</td><td class="tblinfo" id="datareg">V256 FYA</td>
    </tr>
    </tbody>
</table>
</section>
</div>
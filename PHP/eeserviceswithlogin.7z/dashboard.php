<section id="dashboard1">
<table>
	<thead>
	<tr>
		<th class="tblhead" colspan="6">DASHBOARD</th>
    </tr>
    <tr>
    	<th class="tblsubhead" colspan="6">In-Progress..</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    	<td id="ipbay1">Bay One</td><td class="tblinfo" id="ipreg1">X615 GHE</td>
        <td id="ipbay2">Bay Two</td><td class="tblinfo" id="ipreg2">AD52 XRT</td>
        <td id="ipbay3">Bay Three</td><td class="tblinfo" id="ipreg3">V256 FYA</td>
    </tr>
    <tr>
    	<td id="ipcust1">Customer</td><td class="tblinfo" id="ipnom1">Mr J Flopadopalous</td>
        <td id="ipcust2">Customer</td><td class="tblinfo" id="ipnom2">Mrs S Jones</td>
        <td id="ipcust3">Customer</td><td class="tblinfo" id="ipnom3">Mr W Peck</td>
    </tr>
    <tr>
    	<td id="iptime1">Time</td><td class="tblinfo" id="ipt1">15:30</td>
        <td id="iptime2">Time</td><td class="tblinfo" id="ipt2">14:30</td>
        <td id="iptime3">Time</td><td class="tblinfo" id="ipt3">16:30</td>
    </tr>
    </tbody>
</table>
</section>
<section id="dashboard2">
<table>
	<thead>
	<tr>
		<th class="tbldate" colspan="6">Date</th>
    </tr>
    <tr>
    	<th class="tblsubhead" colspan="6">Next Job..</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    	<td id="njbay1">Bay One</td><td class="tblinfo" id="ipreg1">X615 GHE</td>
        <td id="njbay2">Bay Two</td><td class="tblinfo" id="ipreg2">AD52 XRT</td>
        <td id="njbay3">Bay Three</td><td class="tblinfo" id="ipreg3">V256 FYA</td>
    </tr>
    <tr>
    	<td id="njcust1">Customer</td><td class="tblinfo" id="ipnom1">Mr J Smith</td>
        <td id="njcust2">Customer</td><td class="tblinfo" id="ipnom2">Mrs S Jones</td>
        <td id="njcust3">Customer</td><td class="tblinfo" id="ipnom3">Mr W Peck</td>
    </tr>
    <tr>
    	<td id="njtime1">Time</td><td class="tblinfo" id="njt1">15:30</td>
        <td id="njtime2">Time</td><td class="tblinfo" id="njt2">14:30</td>
        <td id="njtime3">Time</td><td class="tblinfo" id="njt3">16:30</td>
    </tr>
    </tbody>
</table>
</section>
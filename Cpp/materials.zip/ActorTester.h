/*
 * ActorTester.h
 *
 *  Created on: Dec 21, 2015
 *      Author: np183
 */

#ifndef ACTORTESTER_H_
#define ACTORTESTER_H_

#include "TesterBase.h"
#include "Container.h"
#include "Actor.h"

class ActorTester : public TesterBase {
public:
	ActorTester();
	~ActorTester();

	void testToLC();
	void testToUC();
	void testShorten();
	void testInterleave();
	void testSequence();

	void testName();
	void testToString();

	void testAct();

	void testMaskAccess();
	void testMemory();
private:
	bool* randMask_(unsigned int size);
	Container randContainer_(unsigned int size, unsigned int minlen,
			unsigned int maxlen);
	Actor* randRecursiveActor_(unsigned int depth);
};

#endif /* ACTORTESTER_H_ */

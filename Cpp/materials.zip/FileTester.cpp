/*
 * FileTester.cpp
 *
 *  Created on: Nov 1, 2016
 *      Author: np183
 */

#include <vector>
#include "FileTester.h"

using std::string;
using std::vector;


typedef unsigned int uint;

FileTester::FileTester() {
}

FileTester::~FileTester() {
}

void FileTester::testFileConstructor() {
	func_("testFileConstructor");

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	File f(name,perms + '0');

	if (f.name() != name) {
		errorOut_("wrong name");
	}

	if (f.read() != static_cast<bool>(perms & 4) ||
			f.write() != static_cast<bool>(perms & 2) ||
			f.execute() != static_cast<bool>(perms & 1)) {
		errorOut_("wrong permissions",1);
	}

	passOut_("tested File constructor");
}

void FileTester::testLinkConstructor() {
	func_("testLinkConstructor");

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	File f(name,perms + '0');
	string oname = randString_(LENGTHOFNAME);

	Link l(oname,&f);

	if (l.name() != oname) {
		errorOut_("wrong name");
	}

	if (l.read() != static_cast<bool>(perms & 4) ||
			l.write() != static_cast<bool>(perms & 2) ||
			l.execute() != static_cast<bool>(perms & 1)) {
		errorOut_("wrong permissions",1);
	}

	passOut_("tested Link constructor");
}

void FileTester::testDirectoryConstructor() {
	func_("testDirectoryConstructor");

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	Directory d(name,perms + '0');

	if (d.name() != name) {
		errorOut_("wrong name");
	}

	if (d.read() != static_cast<bool>(perms & 4) ||
			d.write() != static_cast<bool>(perms & 2) ||
			d.execute() != static_cast<bool>(perms & 1)) {
	  errorOut_("wrong permissions",1);
	}

	passOut_("tested Directory constructor");
}

void FileTester::testDirectorySize() {
	func_("testDirectorySize");

	uint size = rand()% SMALLSIZE + SMALLSIZE;

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	vector<FileBase*> storage;
	{
		Directory d(name,'0'+perms);

		for (auto i=0 ; i<size ; ++i) {
			FileBase* temp = new File(randString_(LENGTHOFNAME),randomPerms_());
			storage.push_back(temp);
			d.add(temp);
		}

		FileBase& f(d);
		if (f.size() != size) {
			errorOut_("Wrong size");
		}
	}

	// d destructor already called.
	// Only now delete the pointers
	for (auto ptr : storage) {
		delete ptr;
	}

	passOut_("tested Directory size");
}

void FileTester::testFileSize() {
	func_("testFileSize");

	uint size = rand()% SMALLSIZE + SMALLSIZE;

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	File f(name,'0'+perms);
	uint fsize = rand()%LARGESIZE + LARGESIZE;
	f.add(randStringSpace_(fsize));

	FileBase& fb(f);
	if (fb.size() != fsize) {
		errorOut_("wrong size");
	}

	passOut_("tested File size");
}

void FileTester::testLinkSize() {
	func_("testLinkSize");

	{ // Test link to directory
		uint size = rand()% SMALLSIZE + SMALLSIZE;

		string name = randString_(LENGTHOFNAME);
		char perms = randomPerms_();

		vector<FileBase*> storage;
		{
		  Directory d(name,'0'+perms);
		  Link l(randString_(LENGTHOFNAME),&d);
		  FileBase& fb(l);
		  for (auto i=0 ; i<size ; ++i) {
		    if (fb.size() != i) {
		      errorOut_("Wrong size of linked directory");
		    }
		    FileBase* temp = new File(randString_(LENGTHOFNAME),randomPerms_());
		    storage.push_back(temp);
		    d.add(temp);
		  }
		  if (fb.size() != size) {
		    errorOut_("Wrong size of linked directory");
		  }
		}

		// d destructor already called.
		// Only now delete the pointers
		for (auto ptr : storage) {
		  delete ptr;
		}
	}
	
	{ // test link to file
		uint size = rand()% SMALLSIZE + SMALLSIZE;

		string name = randString_(LENGTHOFNAME);
		char perms = randomPerms_();

		File f(name,'0'+perms);
		Link l(randString_(LENGTHOFNAME),&f);
		FileBase& fb(l);
		unsigned actsize = 0;
		for (auto i=0 ; i<2 ; ++i) { 
		  if (fb.size() != actsize) {
		    errorOut_("wrong size of linked file",1);
		  }
		  uint fsize = rand()%LARGESIZE + LARGESIZE;
		  f.add(randStringSpace_(fsize));
		  actsize += fsize;
		}
		if (fb.size() != actsize) {
		  errorOut_("wrong size of linked file",1);
		}
	}

	passOut_("tested Link size");
}

void FileTester::testChmod() {
	func_("testChmod");

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	File f(name,'0'+perms);

	for (unsigned int i=0 ; !errorSet_(1) && i<256 ; ++i) {
		char c = static_cast<char>(i);
		if (c <'0' || c>'7') {
			f.chmod(c);
		}
		if (f.read() != static_cast<bool>(perms & 4) ||
			f.write() != static_cast<bool>(perms & 2) ||
			f.execute() != static_cast<bool>(perms & 1)) {
			  errorOut_("wrong permissions");
		}
	}

	passOut_("tested range of chmod");
}

void FileTester::testFileContents() {
	func_("testFileContents");

	// Basic check
	uint size = rand()% SMALLSIZE + SMALLSIZE;

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	File f(name,'0'+perms);
	uint fsize = rand()%LARGESIZE + LARGESIZE;
	string contents = randStringSpace_(fsize);
	f.add(contents);

	auto compare = [&f,&contents,this]() {
		if (f.size() != contents.size()) {
			this->errorOut_("wrong file size");
		}
		else {
			for (auto i=0 ; i<contents.size() ; ++i) {
				if (f[i] != contents[i]) {
					this->errorOut_("wrong contents",1);
					break;
				}
			}
		}
	};

	compare();

	// Extend and check
	for (uint i=0 ; !errorSet_(1|2) && i<SMALLSIZE ; ++i) {
		string temp = randStringSpace_(MEDIUMSIZE);
		contents.append(temp);
		f.add(temp);
		compare();
	}

	passOut_("tested File contents");
}

void FileTester::testLink() {
	func_("testLink");

	{
		string name = randString_(LENGTHOFNAME);
		char perms = randomPerms_();

		File f(name,'0' + perms);
		string oname = randString_(LENGTHOFNAME);

		Link l(oname,&f);

		if (l.link() != &f) {
			errorOut_("returned wrong file");
		}

		f.chmod('0');

		if (l.read() || l.write() || l.execute()) {
		  errorOut_("link does not show permission change",1);
		}

		l.chmod('7');

		if (!f.read() || !f.write() || !f.execute()) {
			errorOut_("chmod of link does not change permissions of the file",2);
		}
	}

	{
		string name = randString_(LENGTHOFNAME);
		char perms = randomPerms_();

		Directory d(name,'0' + perms);
		string oname = randString_(LENGTHOFNAME);

		Link l(oname,&d);

		if (l.link() != &d) {
			errorOut_("returned wrong directory",3);
		}

		d.chmod('0');

		if (l.read() || l.write() || l.execute()) {
		  errorOut_("link does not show permission change",4);
		}

		l.chmod('7');

		if (!d.read() || !d.write() || !d.execute()) {
			errorOut_("chmod of link does not change permissions of the directory",5);
		}
	}

	passOut_("tested Link");
}

void FileTester::testLinkNull() {
	func_("testLinkNull");

	string oname = randString_(LENGTHOFNAME);
	Link l(oname,nullptr);

	l.read();
	l.write();
	l.execute();
	l.chmod('7');
	l.size();

	passOut_("tested Link to nullptr");
}

void FileTester::testEmptyAdd() {
	func_("testEmptyAdd");

	string name = randString_(LENGTHOFNAME);
	char perms = randomPerms_();

	File f(name,'0'+perms);
	Directory d(name,'0'+perms);
	char arr[5];
	f.add(nullptr,0);
	f.add(arr,0);
	if (f.size()!=0) {
		errorOut_("size is not 0");
	}

	for (auto i=0 ; i<MEDIUMSIZE ; ++i) {
		d.add(nullptr);
	}
	for (auto i=0 ; i<d.size() ; ++i) {
		if (d[i]) {
			errorOut_("created directories from null",1);
		}
	}

	passOut_("tested what happens if you add an empty buffer and nullptr");
}

void FileTester::testDirectoryContents() {
	func_("testDirectoryContents");

	uint size = rand()% SMALLSIZE + SMALLSIZE;

	string name = randString_(LENGTHOFNAME);
	char perm = randomPerms_();

	vector<FileBase*> storage;
	vector<string> names;
	vector<char> perms;
	{
		// first round of addition
		Directory d(name,'0'+perm);

		for (auto i=0 ; i<size ; ++i) {
			string tempn = randString_(LENGTHOFNAME);
			char tempperm = randomPerms_();
			FileBase* temp = new File(tempn,tempperm + '0');
			storage.push_back(temp);
			names.push_back(tempn);
			perms.push_back(tempperm);
			d.add(temp);
		}

		auto compare = [&,this]() {
			if (d.size() != storage.size()) {
				errorOut_("wrong size");
			}
			else {
				for (auto i=0 ; i<storage.size() ; ++i) {
					FileBase* temp = d[i];
					if (temp->name() != names[i]) {
						this->errorOut_("wrong name of file",1);
					}
					if (temp->read() != static_cast<bool>(perms[i] & 4) ||
							temp->write() != static_cast<bool>(perms[i] & 2) ||
							temp->execute() != static_cast<bool>(perms[i] & 1)) {
						this->errorOut_("wrong permissions of file",2);
					}
				}
			}
		};
		compare();

		// second round of additions
		for (uint i=0 ; !errorSet_(1|2) && i<SMALLSIZE ; ++i) {
			for (uint j=0 ; !errorSet_(1|2) && j<SMALLSIZE ; ++j) {
				string tempn = randString_(LENGTHOFNAME);
				char tempperm = randomPerms_();
				FileBase* temp = new File(tempn,tempperm + '0');
				storage.push_back(temp);
				names.push_back(tempn);
				perms.push_back(tempperm);
				d.add(temp);
			}
			compare();
		}

	}

	// d destructor already called.
	// Only now delete the pointers
	for (auto ptr : storage) {
		delete ptr;
	}

	passOut_("tested Directory contents");
}

char FileTester::randomPerms_() {
	char ret=7;
	for (uint i = 4 ; i ; i = (i>>1)) {
		if (rand() % 2) ret &= ~i;
	}
	return ret;
}

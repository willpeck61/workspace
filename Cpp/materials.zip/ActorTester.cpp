/*
 * ActorTester.cpp
 *
 *  Created on: Nov 8, 2016
 *      Author: np183
 */

#include <string>
#include <vector>
#include <memory>
#include "ActorTester.h"

using std::string;
using std::vector;
using std::unique_ptr;

typedef unsigned int uint;
typedef unique_ptr<Actor> Ap;

constexpr uint SMALLSIZE=10;
constexpr uint MEDSIZE=1000;
constexpr uint LARGESIZE=1000000;

ActorTester::ActorTester() {
	// TODO Auto-generated constructor stub

}

ActorTester::~ActorTester() {
	// TODO Auto-generated destructor stub
}

void ActorTester::testToLC() {
	func_("testToLC");

	int size = SMALLSIZE + rand()%SMALLSIZE;
	bool* mask = randMask_(size);
	{
		ToLC t(mask,size);

		if (t.name() != "ToLC") {
			errorOut_("Wrong name");
		}

		if (t.toString() != "ToLC(X)") {
			errorOut_("Wrong toString",1);
		}

		if (t.size() != size) {
			errorOut_("Wrong size",2);
		}
		else {
			for (uint i=0 ; !errorSet_(1<<4) && i<size ; ++i) {
				if (t[i] != mask[i]) {
					errorOut_("Wrong mask value",3);
				}
			}
		}

		Container in = randContainer_(SMALLSIZE,size,size+rand()%SMALLSIZE);
		Container out = t.act(in);
		char* inp = in.first();
		char* outp = out.first();
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (size && mask[i%size] && inp[i] >= 'A' && inp[i] <= 'Z') {
					if (outp[i] != inp[i] - 'A' + 'a') {
						errorOut_("did not change a character that should have changed",4);
					}
				}
				else {
					if (inp[i] != outp[i]) {
						errorOut_("changed a character that should not have changed",5);
					}
				}
			}
			inp = in.next();
			outp = out.next();
		}
		if (inp || outp) {
			errorOut_("Wrong number of entries after act",6);
		}
	}
	delete mask;
	passOut_("tested ToLC");
}

void ActorTester::testToUC() {
	func_("testToUC");

	int size = SMALLSIZE + rand()%SMALLSIZE;
	bool* mask = randMask_(size);
	{
		ToUC t(mask,size);

		if (t.name() != "ToUC") {
			errorOut_("Wrong name");
		}

		if (t.toString() != "ToUC(X)") {
			errorOut_("Wrong toString",1);
		}

		if (t.size() != size) {
			errorOut_("Wrong size",2);
		}
		else {
			for (uint i=0 ; !errorSet_(1<<4) && i<size ; ++i) {
				if (t[i] != mask[i]) {
					errorOut_("Wrong mask value",3);
				}
			}
		}

		Container in = randContainer_(SMALLSIZE,size,size+rand()%SMALLSIZE);
		Container out = t.act(in);
		char* inp = in.first();
		char* outp = out.first();
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (size && mask[i%size] && inp[i] >= 'a' && inp[i] <= 'z') {
					if (outp[i] != inp[i] - 'a' + 'A') {
						errorOut_("did not change a character that should have changed",4);
					}
				}
				else {
					if (inp[i] != outp[i]) {
						errorOut_("changed a character that should not have changed",5);
					}
				}
			}
			inp = in.next();
			outp = out.next();
		}
		if (inp || outp) {
			errorOut_("Wrong number of entries after act",6);
		}
	}
	delete mask;

	passOut_("tested ToUC");
}

void ActorTester::testShorten() {
	func_("testShorten");

	int size = SMALLSIZE + rand()%SMALLSIZE;
	bool* mask = randMask_(size);
	{
		Shorten t(mask,size,nullptr);

		if (t.name() != "Shorten") {
			errorOut_("Wrong name");
		}

		if (t.toString() != "Shorten(X)") {
			errorOut_("Wrong toString",1);
		}


		if (t.size() != size) {
			errorOut_("Wrong size",2);
		}
		else {
			for (uint i=0 ; !errorSet_(1<<4) && i<size ; ++i) {
				if (t[i] != mask[i]) {
					errorOut_("Wrong mask value",3);
				}
			}
		}

		// Shorten without operation
		unsigned int contsize = SMALLSIZE + rand()%SMALLSIZE;
		Container in = randContainer_(contsize,size,size+1+rand()%SMALLSIZE);
		{
			Container out = t.act(in);

			char* inp = in.first();
			char* outp = out.first();
			uint i=0;
			while (inp) {
				if (mask[i]) {
					if (!outp) {
						errorOut_("Missing things in act result",4);
						break;
					}
					for (uint i=0 ; inp[i] ; ++i) {
						if (outp[i] != inp[i]) {
							errorOut_("Wrong entry in output",5);
						}
					}
					outp = out.next();
				}
				inp = in.next();
				i = (size ? (i+1)%size : i+1);
			}
			if (inp || outp) {
				errorOut_("Missing things in act result",6);
			}
		}

		// Shorten with a sub-operation
		bool wmask[1];
		wmask[0]=true; // Turn all lower case to upper case

		ToUC* uc = new ToUC(wmask,1);
		Shorten t1(mask,size,uc);
		if (t1.toString() != "Shorten(ToUC(X))") {
			errorOut_("Wrong toString",7);
		}
		{
			Container out = t1.act(in);
			char* inp = in.first();
			char* outp = out.first();
			uint i=0;
			while (inp) {
				if (mask[i]) {
					if (!outp) {
						errorOut_("Missing things in act result",8);
						break;
					}
					for (uint j=0 ; inp[j] ; ++j) {
						if (inp[j] >= 'a' && inp[j] <= 'z') {
							if (outp[j] != inp[j] -'a' + 'A') {
								errorOut_("Wrong entry in output",9);
							}
						} else {
							if (outp[j] != inp[j]) {
								errorOut_("Wrong entry in output",9);
							}
						}
					}
					outp = out.next();
				}
				inp = in.next();
				i = (size ? (i+1)%size : i+1);
			}
			if (inp || outp) {
				errorOut_("Missing things in act result",8);
			}
		}
	}
	delete mask;

	passOut_("tested Shorten");
}

void ActorTester::testInterleave() {
	func_("testInterleave");

	{ // Interleave with two suboperations
		ToUC* uc1=new ToUC(nullptr,0);
		ToUC* uc2=new ToUC(nullptr,0);
		Interleave t(uc1,uc2);

		if (t.name() != "Interleave") {
			errorOut_("Wrong name");
		}

		if (t.toString() != "Interleave(ToUC(X),ToUC(X))") {
			errorOut_("Wrong toString",1);
		}

		uint size = SMALLSIZE + rand()%SMALLSIZE;
		uint contsize = SMALLSIZE + rand()%SMALLSIZE + 1;
		Container in = randContainer_(contsize,size,size+rand()%SMALLSIZE);
		Container out = t.act(in);
		char* inp = in.first();
		char* outp = out.first();
		bool even=true;
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp[i] != inp[i]) {
					errorOut_("Wrong entry in output",2);
				}
			}
			if (!even) {
				inp = in.next();
			}
			outp = out.next();
			even = !even;
		}
		if (inp || outp) {
			errorOut_("Wrong size of result",3);
		}
	}

	{ // Interleave with one suboperation
		ToUC* uc1=new ToUC(nullptr,0);
		ToUC* uc2=new ToUC(nullptr,0);
		// Interleave with two suboperations
		Interleave t1(uc1,nullptr);
		Interleave t2(nullptr,uc2);

		if (t1.toString() != "Interleave(ToUC(X))" ||
				t2.toString() != "Interleave(ToUC(X))") {
			errorOut_("Wrong toString",4);
		}

		uint size = SMALLSIZE + rand()%SMALLSIZE;
		uint contsize = SMALLSIZE + rand()%SMALLSIZE + 1;
		Container in = randContainer_(contsize,size,size+rand()%SMALLSIZE);
		Container out1 = t1.act(in);
		Container out2 = t2.act(in);
		char* inp = in.first();
		char* outp1 = out1.first();
		char* outp2 = out2.first();
		while (inp && outp1 && outp2) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp1[i] != inp[i] ||
						outp2[i] != inp[i]) {
					errorOut_("Wrong entry in output",5);
				}
			}
			inp = in.next();
			outp1 = out1.next();
			outp2 = out2.next();
		}
		if (inp || outp1 || outp2) {
			errorOut_("Wrong size of result",6);
		}
	}

	{ // Interleave with no suboperation
		Interleave t(nullptr,nullptr);

		if (t.toString() != "Interleave(X)") {
			errorOut_("Wrong toString",7);
		}

		uint size = SMALLSIZE + rand()%SMALLSIZE;
		uint contsize = SMALLSIZE + rand()%SMALLSIZE + 1;
		Container in = randContainer_(contsize,size,size+rand()%SMALLSIZE);
		Container out = t.act(in);
		char* inp = in.first();
		char* outp = out.first();
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp[i] != inp[i]) {
					errorOut_("Wrong entry in output",8);
				}
			}
			inp = in.next();
			outp = out.next();
		}
		if (inp || outp) {
			errorOut_("Wrong size of result",9);
		}
	}

	passOut_("tested Interleave");
}

void ActorTester::testSequence() {
	func_("testSequence");

	{ // Sequence with two suboperations
		ToUC* uc1=new ToUC(nullptr,0);
		ToUC* uc2=new ToUC(nullptr,0);
		Sequence t(uc1,uc2);

		if (t.name() != "Sequence") {
			errorOut_("Wrong name");
		}

		if (t.toString() != "Sequence(ToUC(X),ToUC(X))") {
			errorOut_("Wrong toString",1);
		}

		uint size = SMALLSIZE + rand()%SMALLSIZE;
		uint contsize = SMALLSIZE + rand()%SMALLSIZE + 1;
		Container in = randContainer_(contsize,size,size+rand()%SMALLSIZE);
		Container out = t.act(in);
		char* inp = in.first();
		char* outp = out.first();
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp[i] != inp[i]) {
					errorOut_("Wrong entry in output",2);
				}
			}
			inp = in.next();
			outp = out.next();
		}
		if (!outp) {
			errorOut_("Wrong size of result",3);
		}
		inp = in.first();
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp[i] != inp[i]) {
					errorOut_("Wrong entry in output",4);
				}
			}
			inp = in.next();
			outp = out.next();
		}
		if (inp || outp) {
			errorOut_("Wrong size of result",5);
		}
	}

	{ // Sequence with one suboperations
		ToUC* uc1=new ToUC(nullptr,0);
		ToUC* uc2=new ToUC(nullptr,0);
		Sequence t1(uc1,nullptr);
		Sequence t2(nullptr,uc2);

		if (t1.toString() != "Sequence(ToUC(X))" ||
				t2.toString() != "Sequence(ToUC(X))") {
			errorOut_("Wrong toString",6);
		}

		uint size = SMALLSIZE + rand()%SMALLSIZE;
		uint contsize = SMALLSIZE + rand()%SMALLSIZE + 1;
		Container in = randContainer_(contsize,size,size+rand()%SMALLSIZE);
		Container out1 = t1.act(in);
		Container out2 = t2.act(in);
		char* inp = in.first();
		char* outp1 = out1.first();
		char* outp2 = out2.first();
		while (inp && outp1 && outp2) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp1[i] != inp[i] ||
						outp2[i] != inp[i]) {
					errorOut_("Wrong entry in output",7);
				}
			}
			inp = in.next();
			outp1 = out1.next();
			outp2 = out2.next();
		}
		if (inp || outp1 || outp2) {
			errorOut_("Wrong size of result",8);
		}
	}

	{ // Sequence with no suboperations
		Sequence t(nullptr,nullptr);

		if (t.toString() != "Sequence(X)") {
			errorOut_("Wrong toString",9);
		}

		uint size = SMALLSIZE + rand()%SMALLSIZE;
		uint contsize = SMALLSIZE + rand()%SMALLSIZE + 1;
		Container in = randContainer_(contsize,size,size+rand()%SMALLSIZE);
		Container out = t.act(in);
		char* inp = in.first();
		char* outp = out.first();
		while (inp && outp) {
			for (uint i=0 ; inp[i] ; ++i) {
				if (outp[i] != inp[i]) {
					errorOut_("Wrong entry in output",10);
				}
			}
			inp = in.next();
			outp = out.next();
		}
		if (inp || outp) {
			errorOut_("Wrong size of result",11);
		}
	}

	passOut_("tested Sequence");
}

void ActorTester::testName() {
	func_("testName");

	vector<Ap> acts;
	bool mask[1];
	mask[0]=false;
	acts.push_back(Ap(new ToUC(mask,1)));
	acts.push_back(Ap(new ToLC(mask,1)));
	acts.push_back(Ap(new Shorten(mask,1,new ToLC(mask,1))));
	acts.push_back(Ap(new Interleave(new ToLC(mask,1),new ToUC(mask,1))));
	acts.push_back(Ap(new Sequence(new ToLC(mask,1),new ToUC(mask,1))));

	if (acts.at(0)->name() != "ToUC" ||
			acts.at(1)->name() != "ToLC" ||
			acts.at(2)->name() != "Shorten" ||
			acts.at(3)->name() != "Interleave" ||
			acts.at(4)->name() != "Sequence") {
		errorOut_("wrong name");
	}
	passOut_("tested the name function");
}

void ActorTester::testToString() {
	func_("testToString");

	vector<Ap> acts;
	bool mask[1];
	mask[0]=false;
	acts.push_back(Ap(new ToUC(mask,1)));
	acts.push_back(Ap(new ToLC(mask,1)));
	acts.push_back(Ap(new Shorten(mask,1,new ToLC(mask,1))));
	acts.push_back(Ap(new Interleave(new ToLC(mask,1),new ToUC(mask,1))));
	acts.push_back(Ap(new Sequence(new ToLC(mask,1),new ToUC(mask,1))));

	if (acts.at(0)->toString() != "ToUC(X)" ||
			acts.at(1)->toString() != "ToLC(X)" ||
			acts.at(2)->toString() != "Shorten(ToLC(X))" ||
			acts.at(3)->toString() != "Interleave(ToLC(X),ToUC(X))" ||
			acts.at(4)->toString() != "Sequence(ToLC(X),ToUC(X))") {
		errorOut_("wrong toString");
	}
	passOut_("tested the toString function");
}

void ActorTester::testAct() {
	func_("testAct");

	// Shorten(Sequence(ToUC(X),ToLC(X))) = ToUC(X)
	{
		uint size = MEDSIZE;
		uint contsize = SMALLSIZE;
		Container in = randContainer_(contsize,size,size);

		bool* charmask = randMask_(size);

		bool shortmask[2*contsize];
		for (unsigned int i=0 ; i<contsize ; ++i) {
			shortmask[i]=true;
			shortmask[i+contsize]=false;
		}
		Shorten s(shortmask,2*contsize,
				  new Sequence(new ToUC(charmask,size),new ToLC(charmask,size)));
		ToUC uc(charmask,size);

		Container out1 = s.act(in);
		Container out2 = uc.act(in);

		if (out1 != out2) {
			errorOut_("Shorten(Sequence(ToUC(X),ToUC(X))) != ToUC(X)");
		}
		delete [] charmask;
	}

	// Shorten(Interleave(ToUC(X),Sequence(ToUC(X),ToLC(X)))) =
	//         Interleave(ToUC(X),ToUC(X))
	{
		uint size = MEDSIZE;
		uint contsize = SMALLSIZE;
		Container in = randContainer_(contsize,size,size);

		bool* charmask = randMask_(size);

		bool shortmask[3*contsize];
		for (unsigned int i=0 ; i<contsize ; ++i) {
			shortmask[i]=true;
			shortmask[i+contsize]=true;
			shortmask[i+2*contsize]=false;
		}
		Shorten s(shortmask,3*contsize,
				  new Interleave(new ToUC(charmask,size),
						  	     new Sequence(new ToUC(charmask,size),
						  	    		 	  new ToLC(charmask,size))));
		Interleave i(new ToUC(charmask,size),new ToUC(charmask,size));

		Container out1 = s.act(in);
		Container out2 = i.act(in);

		if (out1 != out2) {
			errorOut_("Shorten(Interleave(ToUC(X),Sequence(ToUC(X),ToLC(X)))) != Interleave(ToUC(X),ToUC(X))",1);
		}
		delete [] charmask;
	}

	// Shorten(Interleave(ToUC(X),ToLC(X))) = ToUC(X)
	{

		uint size = MEDSIZE;
		uint contsize = SMALLSIZE;
		Container in = randContainer_(contsize,size,size);

		bool* charmask = randMask_(size);

		bool shortmask[2*contsize];
		for (unsigned int i=0 ; i<2*contsize ; ++i) {
			shortmask[i]=!static_cast<bool>(i%2);
		}
		Shorten s(shortmask,2*contsize,
				  new Interleave(new ToUC(charmask,size),new ToLC(charmask,size)));
		ToUC uc(charmask,size);

		Container out1 = s.act(in);
		Container out2 = uc.act(in);

		if (out1 != out2) {
			errorOut_("Shorten(Interleave(ToUC(X),ToUC(X))) != ToUC(X)",2);
		}
		delete [] charmask;
	}

	passOut_("tested act");
}

void ActorTester::testMaskAccess() {
	func_("testMaskAccess");
	{
		uint size = LARGESIZE;
		bool* charmask = randMask_(size);
		Shorten s(charmask,size,nullptr);
		ToUC uc(charmask,size);
		ToLC lc(charmask,size);
		delete [] charmask;

		for (auto i=0 ; i < size ; ++i) {
			s[i];
			uc[i];
			lc[i];
		}
	}

	{
		Shorten s(nullptr,0,nullptr);
		ToUC uc(nullptr,0);
		ToLC lc(nullptr,0);

		Container in = randContainer_(MEDSIZE,MEDSIZE,MEDSIZE);
		s.act(in);
		uc.act(in);
		lc.act(in);
	}

	passOut_("tested mask access");
}

void ActorTester::testMemory() {
	func_("testMemory");

	const uint depth=20;
	const uint repetitions=1000000;
	for (uint i=0 ; i<repetitions ; ++i) {
		Actor* a=randRecursiveActor_(depth);
		delete a;
	}
	passOut_("tested memory handling");
}

bool* ActorTester::randMask_(uint size) {
	bool* ret = new bool[size];
	for (uint i=0 ; i<size ; ++i) {
		ret[i] = static_cast<bool>(rand()%2);
	}
	return ret;
}

Container ActorTester::randContainer_(uint size, uint minlen, uint maxlen) {
	Container ret;
	if (minlen >= maxlen) {
		maxlen=minlen+1;
	}
	for (uint i=0 ; i<size ; ++i) {
		string temp = randString_(minlen + rand()%(maxlen-minlen));
		ret.add(temp.c_str());
	}
	return ret;
}

Actor* ActorTester::randRecursiveActor_(unsigned int depth) {
	bool mask[5];
	for (uint i=0 ; i<5 ; ++i) {
		mask[i] = rand()%2;
	}
	uint choose = rand()%10+1;
	if (!depth || choose<3) { // 2/10
		if (rand()%2) {
			return new ToLC(mask,5);
		} else {
			return new ToUC(mask,5);
		}
	} else if (choose < 7) { // 4/10
		if (rand()%2) {
			return new Sequence(randRecursiveActor_(depth-1),
					randRecursiveActor_(depth-1));
		} else {
			return new Interleave(randRecursiveActor_(depth-1),
					randRecursiveActor_(depth-1));
		}
	} else { // 4/10
		return new Shorten(mask,5,randRecursiveActor_(depth-1));
	}
}

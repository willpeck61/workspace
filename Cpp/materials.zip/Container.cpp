/*
 * Container.cpp
 *
 *  Created on: 7 Nov 2016
 *      Author: np183
 */

#include "Container.h"

constexpr int INITIALSIZE=5;
constexpr int INCREASESIZE=5;

Container::Container()
: numElements_(0), capacity_(INITIALSIZE), ptr_(new unsigned int), array_{new char*[capacity_]}
{
	*ptr_ = capacity_;
}

Container::Container(const Container& other)
: numElements_{other.numElements_},
  capacity_{other.capacity_},
  ptr_{new unsigned int},
  array_{new char*[capacity_]}
  {
	  if (ptr_) {
		  *ptr_ = capacity_;
	  }
	  for (unsigned int i=0 ; array_ && i<numElements_ ; ++i) {
		  array_[i]=copy_(other.array_[i]);
	  }
  }

  Container::Container(Container&& other)
  : numElements_{other.numElements_},
	capacity_{other.capacity_},
	ptr_{other.ptr_},
	array_{other.array_}
	{
		*ptr_ = capacity_;
		other.array_ = nullptr;
		other.numElements_=0;
		other.ptr_ = nullptr;
		other.capacity_=0;
	}

	Container::~Container() {
		if (array_) {
			for (unsigned int i=0 ; i<numElements_ ; ++i) {
				if (array_[i]) {
					delete [] array_[i];
				}
			}
			delete [] array_;
		}
		if (ptr_)
			delete ptr_;
	}

	void Container::add(const char* val) {
		if (numElements_ == capacity_) {
			char** temp = new char*[capacity_+INCREASESIZE];
			for (int i=0 ; i<numElements_ ; ++i) {
				temp[i] = array_[i];
			}
			delete [] array_;
			array_ = temp;
			capacity_ += INCREASESIZE;
		}
		array_[numElements_++]=copy_(val);
		*ptr_ = capacity_;
	}

	char* Container::first() const {
		if (array_ && ptr_ && numElements_) {
			*ptr_ = 1;
			return array_[0];
		}
		return nullptr;
	}

	char* Container::next() const {
		if (array_ && ptr_ && *ptr_ < numElements_) {
			return array_[(*ptr_)++];
		}
		return nullptr;
	}

	bool Container::operator==(const Container& other) const {
		// Same number of elements
		if (numElements_ != other.numElements_) {
			return false;
		}
		// Agree on nullptr of main array
		if ((other.array_ && !array_) ||
			(array_ && !other.array_)) {
			return false;
		}

		// No access if both arrays are nullptr
		for (unsigned int i=0 ; i<numElements_ ; ++i) {
			// Array on nullptr of i-th entry
			if ((!array_[i] && other.array_[i]) ||
				(array_[i] && !other.array_[i])) {
				return false;
			}
			// If both nullptr check next
			if (!array_[i] && !other.array_[i]) {
				break;
			}
			// Compare char by char
			unsigned int j=0;
			for ( ; array_[i][j] && other.array_[i][j] ; ++j) {
				if (array_[i][j] != other.array_[i][j]) {
					return false;
				}
			}
			// Both ended together
			if (array_[i][j] || other.array_[i][j]) {
				return false;
			}
		}
		return true;
	}

	bool Container::operator!=(const Container& other) const {
		return !((*this)==other);
	}
	Container& Container::operator=(const Container& other) {
		if (this != &other) {
			// Release the char* stored inside
			for (unsigned int i=0 ; array_ && i<numElements_ ; ++i) {
				if (array_[i]) {
					delete [] array_[i];
					array_[i] = nullptr;
				}
			}

			// Reallocate main array if required
			if (capacity_ < other.numElements_) {
			  char** temp = new char*[other.capacity_];
			  capacity_ = other.capacity_;
			  if (array_) {
			    delete [] array_;
			  }
			  array_ = temp;
			}

			// Deep copy actual elements
			numElements_ = other.numElements_;
			for (int i=0 ; i<numElements_ ; ++i) {
				array_[i] = copy_(other.array_[i]);
			}
			*ptr_ = capacity_;
		}
		return *this;
	}

	Container& Container::operator=(Container&& other) {
		if (this != &other) {
			char** temp = array_;
			array_ = other.array_;
			other.array_ = temp;

			int tempN = numElements_;
			numElements_ = other.numElements_;
			other.numElements_ = tempN;

			tempN = capacity_;
			capacity_ = other.capacity_;
			other.capacity_ = tempN;

			*ptr_ = capacity_;
			*other.ptr_ = other.capacity_;
		}
		return *this;
	}

	char* Container::copy_(const char* source) {
		if (source) {
			unsigned int i=0;
			for (; source[i] ; ++i) {}
			char* temp = new char[i+1];
			for (unsigned int j=0 ; j<i ; ++j) {
				temp[j]=source[j];
			}
			temp[i]=0;
			return temp;
		}
		return nullptr;
	}


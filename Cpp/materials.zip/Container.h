/*
 * Container.h
 *
 *  Created on: 7 Nov 2016
 *      Author: np183
 */

#ifndef CONTAINER_H_
#define CONTAINER_H_

// A container for c-type strings (null terminated char array)
class Container {
public:
	Container();
	Container(const Container&);
	Container(Container&&);

	~Container();

	// Accepts a null terminated char array.
	// Adding nullptr will succeed but will make
	// iteration over the Container impossible
	void add(const char*);

	// Access to the first and the subsequent
	// members of the Container
	// Expected usage:
	// Container c;
	// // ... add things to c
	// char* it = c.first();
	// while(it) {
	//    // Do something with it
	//    it = c.next();
	// }
	//
	// for (char* it = c.first() ; it ; it = c.next()) {
	//    // Do something with it
	// }
	// Notice that every change to the Container
	// will lead to losing the location within the
	// Container.
	// So iteration should be done as above and inside the
	// loops there should be no changes to the Container
	char* first() const;
	char* next() const;

	bool operator== (const Container& other) const;
	bool operator!= (const Container& other) const;
	// Assignment operators with copy and move semantics
	Container& operator=(const Container&);
	Container& operator=(Container&&);
private:
	char* copy_(const char* source);

	unsigned int numElements_;
	unsigned int capacity_;
	unsigned int* ptr_;
	char** array_;

};

#endif /* CONTAINER_H_ */

#/bin/bash

runSimpleTest() {
    local executable="$1"
    local argument="$2"
    local noexecutable="${1} does not exist!"
    local executablefail="${1} ${2} exited abnormally!"
    local executablesucc="${1} ${2} exited normally"

    if [ ! -e "${executable}.txt" ]
    then
	echo "" > ${executable}.txt
    fi

    echo "Running test ${executable} ${argument}" >> ${executable}.txt
    echo "======================================" >> ${executable}.txt
    if [ -e "$executable" ]
    then
	./${executable} ${argument} &>> ${executable}.txt
	if [ $? -eq 0 ]
	then
	    echo "${executablesucc}"
	else
	    echo "${executablefail}"
	fi
    else
	echo "${noexecutable}"
    fi
    echo "" >> ${executable}.txt
}


###################################################################
############ MAIN CODE ############################################
###################################################################

if [ ! -e "TestDirectory" ]
then
    mkdir TestDirectory
fi
cd TestDirectory

if [ ! -e "CopiedFilesFile" ]
then
    for file in File.cpp File.h
    do
	cp ../${file} .
    done
    
    for file in makefile \
	        TesterBase.cpp TesterBase.h \
	        FileTester.h FileTester.cpp \
                FileMain.cpp 
    do
	wget "https://campus.cs.le.ac.uk/teaching/resources/CO7105/Worksheets/assessment2/test/${file}" >& /dev/null
    done

    touch CopiedFilesFile
fi

make FileMain &> FileCompilation.txt

ulimit -SH -c 0            # Maximum size of core files
ulimit -SH -d 4000         # maximum size of process' data segment
ulimit -SH -f 12000         # maximum size of files created by the shell
# ulimit -l - I don't have permissions ???
# ulimit -SH -l 4000         # maximum size that may be locked into memory
ulimit -SH -m 1            # masimum resident set size
ulimit -SH -n 50            # maximum number of open file descriptions

##ulimit -S -u 10             # max number of processes
#ulimit -SH -p 20           # pipe buffer size
#ulimit -SH -a                 # report on limits




ulimit -S -t 480              # maximum CPU time in seconds

ulimit -SH -s 4000          # maximum stack size
ulimit -SH -v 200000        # maximum virtual memory per process

runSimpleTest FileMain a   # t.testEmptyAdd()
runSimpleTest FileMain b   # t.testLink()
runSimpleTest FileMain c   # t.testLinkConstructor()
runSimpleTest FileMain d   # t.testDirectoryContents()
runSimpleTest FileMain e   # t.testDirectoryConstructor()
runSimpleTest FileMain f   # t.testDirectorySize()
runSimpleTest FileMain g   # t.testLinkSize()
runSimpleTest FileMain h   # t.testFileSize()
runSimpleTest FileMain i   # t.testFileContents()
runSimpleTest FileMain j   # t.testFileConstructor()
runSimpleTest FileMain k   # t.testChmod()
runSimpleTest FileMain l   # t.testLinkNull()
echo "Finished running all FileMain tests"

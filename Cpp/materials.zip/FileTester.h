/*
 * FileTester.h
 *
 *  Created on: Nov 1, 2016
 *      Author: np183
 */
#ifndef FILETESTER_H_
#define FILETESTER_H_

#include "TesterBase.h"
#include "File.h"

class FileTester : public TesterBase {
public:
	static constexpr unsigned int LENGTHOFNAME = 20;
	static constexpr unsigned int SMALLSIZE = 20;
	static constexpr unsigned int MEDIUMSIZE = 200;
	static constexpr unsigned int LARGESIZE = 2000;

	FileTester();
	~FileTester();

	void testFileConstructor();
	void testLinkConstructor();
	void testDirectoryConstructor();

	void testDirectorySize();
	void testFileSize();
	void testLinkSize();
	void testChmod();
	void testFileContents();
	void testLink();
	void testLinkNull();
	void testEmptyAdd();
	void testDirectoryContents();
private:
	char randomPerms_();
};

#endif /* FILETESTER_H_ */


// AUTOMATICALLY GENERATED DO NOT EDIT

#include "ActorTester.h"

int main(int argc, char* argv[]) {

	if (false) {
		for (unsigned int i=0 ; i<1 ; ++i) {
			ActorTester t;
		}
		return 0;
	}

	while(argc > 1) {

		switch (argv[--argc][0]) {
		case 'a':
		{
			ActorTester t;
			t.testInterleave();
		}
		break;
		case 'b':
		{
			ActorTester t;
			t.testToUC();
		}
		break;
		case 'c':
		{
			ActorTester t;
			t.testShorten();
		}
		break;
		case 'd':
		{
			ActorTester t;
			t.testAct();
		}
		break;
		case 'e':
		{
			ActorTester t;
			t.testToLC();
		}
		break;
		case 'f':
		{
			ActorTester t;
			t.testToString();
		}
		break;
		case 'g':
		{
			ActorTester t;
			t.testName();
		}
		break;
		case 'h':
		{
			ActorTester t;
			t.testSequence();
		}
		break;
		case 'i':
		{
			ActorTester t;
			t.testMemory();
		}
		break;
		case 'j':
		default:
		{
			ActorTester t;
			t.testMaskAccess();
		}
		break;
		}
	}
	 return 0;
}

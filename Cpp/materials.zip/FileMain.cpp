// AUTOMATICALLY GENERATED DO NOT EDIT

#include "FileTester.h"

int main(int argc, char* argv[]) {

	if (false) {
		for (unsigned int i=0 ; i<1 ; ++i) {
			FileTester t;
		}
		return 0;
	}

	while(argc > 1) {

		switch (argv[--argc][0]) {
		case 'a':
		{
			FileTester t;
			t.testEmptyAdd();
		}
		break;
		case 'b':
		{
			FileTester t;
			t.testLink();
		}
		break;
		case 'c':
		{
			FileTester t;
			t.testLinkConstructor();
		}
		break;
		case 'd':
		{
			FileTester t;
			t.testDirectoryContents();
		}
		break;
		case 'e':
		{
			FileTester t;
			t.testDirectoryConstructor();
		}
		break;
		case 'f':
		{
			FileTester t;
			t.testDirectorySize();
		}
		break;
		case 'g':
		{
			FileTester t;
			t.testLinkSize();
		}
		break;
		case 'h':
		{
			FileTester t;
			t.testFileSize();
		}
		break;
		case 'i':
		{
			FileTester t;
			t.testFileContents();
		}
		break;
		case 'j':
		{
			FileTester t;
			t.testFileConstructor();
		}
		break;
		case 'k':
		{
			FileTester t;
			t.testChmod();
		}
		break;
		case 'l':
		default:
		{
			FileTester t;
			t.testLinkNull();
		}
		break;
		}
	}
	 return 0;
}
